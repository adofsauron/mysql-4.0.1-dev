/* rsa.h for openSSL */


#ifndef yaSSL_rsa_h__
#define yaSSL_rsa_h__

enum { RSA_F4 = 1 };


#endif /* yaSSL_rsa_h__ */
