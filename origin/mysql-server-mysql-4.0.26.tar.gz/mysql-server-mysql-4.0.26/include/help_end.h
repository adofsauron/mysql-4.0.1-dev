#ifdef __NETWARE__
#undef printf
#undef puts
#undef fputs
#undef fputc
#undef putchar
#endif
