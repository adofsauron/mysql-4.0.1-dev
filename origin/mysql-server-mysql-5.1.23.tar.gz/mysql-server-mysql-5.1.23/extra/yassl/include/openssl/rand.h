/* rand.h for openSSL */

