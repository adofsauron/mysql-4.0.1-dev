rm -f $MYSQLTEST_VARDIR/slave-data/*-bin.*
rm -f $MYSQLTEST_VARDIR/slave-data/master.info
rm -f $MYSQLTEST_VARDIR/slave-data/*.index


