#include <stdio.h>

char *fgetln(FILE *stream, size_t *len);
