
#include "my_config.h"
#include "sys.h"

#if defined(LIBC_SCCS) && !defined(lint)
#define __RCSID(x)
#define __COPYRIGHT(x)
#endif
#define __RENAME(x)
#define _DIAGASSERT(x)

#if !defined(__attribute__) && (defined(__cplusplus) || !defined(__GNUC__)  || __GNUC__ == 2 && __GNUC_MINOR__ < 8)
#define __attribute__(A)
#endif


