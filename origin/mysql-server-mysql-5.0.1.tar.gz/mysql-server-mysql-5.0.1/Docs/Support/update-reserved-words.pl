#!/usr/bin/perl

# Based on a Emacs macro by david@mysql.com
# Implemented in Perl by jeremy@mysql.com
# 2001-11-20 Fixups by arjen@mysql.com, 2 keywords and 15 synonyms were missing
# 2001-12-07 Fixup by arjen@mysql.com, add column headings for multitable.
# 2002-05-01 Fixup by arjen@mysql.com, use 3 columns instead of 4.
# 2002-05-03 Fixup by arjen@mysql.com, fill last row to full # of columns.
# 2002-06-14 Fixup by arjen@mysql.com, Issue a "bk edit manual.texi".

print STDERR "Scanning lex.h for symbols..\n";
open LEX, "<../sql/lex.h";
while($line = <LEX>) {
  if($line =~ /\{\s*\"([A-Z_]+)\"/) {
    $words{$1} = $1;
  } elsif($line =~ /sql_functions/) {
    last;
  };
};
close LEX;

print STDERR "Scanning sql_yacc.yy for non-reserved words...\n";
open YACC, "<../sql/sql_yacc.yy";
while(<YACC> !~ /^keyword:/) {};
while(($line = <YACC>) =~ /[\s|]+([A-Z_]+)/) {
  $keyword = $1;
  $keyword =~ s/_SYM//;
  delete $words{$keyword};
};
close YACC;


print STDERR "Copying reserved words to an array...\n";
foreach(keys %words) { push @words, $words{$_}; };

print STDERR "Sorting array...\n";
@words = sort @words;

printf STDERR "There are %i reserved words.\n", scalar @words;

@pre  = ("\@item", " \@tab", " \@tab");

$list = "";
for($i=0; $word = shift(@words); $i++) {
  $list .= sprintf "%s %s\n", $pre[$i%3], "\@code\{$word\}";
}
# Fill last row to full # of columns.
for( ; $i%3; $i++) {
  $list .= sprintf "%s\n", $pre[$i%3];
}

`bk edit manual.texi`;

open OLD, "<manual.texi";
open NEW, ">manual-tmp.texi";

print STDERR "Copying beginning of manual.texi...\n";
while(($line = <OLD>) !~ /START_OF_RESERVED_WORDS/) { print NEW $line; };
print NEW "\@c START_OF_RESERVED_WORDS\n\n";
printf NEW "\@c Reserved word list updated %s by %s.\n".
           "\@c To regenerate, use Support/update-reserved-words.pl.\n\n",
           &pretty_date, $ENV{USER};

print STDERR "Inserting list of reserved words...\n";
# Ensure the fractions add up to 100% otherwise it looks funny in print:
print NEW "\@multitable \@columnfractions .33 .33 .34\n";
print NEW "\@item \@strong{Word}\n \@tab \@strong{Word}\n \@tab \@strong{Word}\n";
print NEW $list;
print NEW "\@end multitable\n";
print STDERR "Skipping over old list...\n";
while(($line = <OLD>) !~ /END_OF_RESERVED_WORDS/) {};
print NEW "\n\@c END_OF_RESERVED_WORDS\n";
print STDERR "Copying end of manual.texi...\n";
while($line = <OLD>) { print NEW $line; };

close OLD;
close NEW;

print STDERR "Moving manual-tmp.texi to manual.texi...\n";
unlink "manual.texi";
rename "manual-tmp.texi", "manual.texi";

print STDERR "Reserved word list updated successfully!\n";

sub pretty_date {
  @time = ($time = shift)?((localtime($time))[0..6]):((localtime)[0..6]);

  ($sec, $min, $hour, $mday, $mon, $year, $wday) = @time;
  $wday = (Sun,Mon,Tue,Wed,Thu,Fri,Sat)[$wday];
  $mon = (Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)[$mon];
  $year += 1900;

  $pretty = sprintf("%s %s %2i %02i:%02i:%02i %i",
                    $wday, $mon, $mday, $hour, $min, $sec, $year);

  return $pretty;
};

